import PrimeVue from 'primevue/config'
import ToastService from 'primevue/toastservice'
import ConfirmationService from 'primevue/confirmationservice'
import AnimateOnScroll from 'primevue/animateonscroll'

import Aura from '@primeuix/themes/aura'

export function setupPrimeVue(app: any) {
  app.use(PrimeVue, {
    theme: {
      preset: Aura,
      options: {
        darkModeSelector: false,
      },
    },
    locale: {
      am: 'AM',
      pm: 'PM',
    },
  })

  app.use(ToastService)
  app.use(ConfirmationService)
  app.directive('animateonscroll', AnimateOnScroll)
}
