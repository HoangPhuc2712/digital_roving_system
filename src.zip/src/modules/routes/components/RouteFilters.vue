<script setup lang="ts">
import { computed } from 'vue'
import BaseFilter from '@/components/common/filters/BaseFilter.vue'

const props = defineProps<{
  areaOptions: { label: string; value: number }[]
  modelAreaId: number | null
  modelStatus: 'ALL' | 'ACTIVE' | 'INACTIVE'
  modelSearch: string
}>()

const emit = defineEmits<{
  (e: 'update:modelAreaId', v: number | null): void
  (e: 'update:modelStatus', v: 'ALL' | 'ACTIVE' | 'INACTIVE'): void
  (e: 'update:modelSearch', v: string): void
  (e: 'clear'): void
}>()

const statusOptions = [
  { label: 'All', value: 'ALL' },
  { label: 'Active', value: 'ACTIVE' },
  { label: 'Inactive', value: 'INACTIVE' },
]

const dropdowns = computed(() => [
  {
    key: 'areaId',
    label: 'Area',
    modelValue: props.modelAreaId,
    options: props.areaOptions,
    widthClass: 'w-full md:w-[280px]',
  },
  {
    key: 'status',
    label: 'Status',
    modelValue: props.modelStatus,
    options: statusOptions,
    showClear: false,
    widthClass: 'w-full md:w-[280px]',
  },
])

function onDropdownUpdate(payload: { key: string; value: any }) {
  if (payload.key === 'areaId') emit('update:modelAreaId', payload.value)
  if (payload.key === 'status') emit('update:modelStatus', payload.value)
}
</script>

<template>
  <BaseFilter
    :dropdowns="dropdowns"
    :modelSearch="props.modelSearch"
    :showSearch="true"
    :showDateSelection="false"
    @update:modelSearch="emit('update:modelSearch', $event)"
    @update:dropdown="onDropdownUpdate"
    @clear="emit('clear')"
  />
</template>
