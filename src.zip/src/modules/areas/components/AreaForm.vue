<script setup lang="ts">
import { computed, reactive, ref, watch } from 'vue'
import Dialog from 'primevue/dialog'

import BaseButton from '@/components/common/buttons/BaseButton.vue'
import BaseInput from '@/components/common/inputs/BaseInput.vue'

import { createAreaMock, updateAreaMock } from '@/modules/areas/areas.api'

export type AreaFormMode = 'new' | 'view' | 'edit'

export type AreaFormModel = {
  area_id?: number
  area_code: string
  area_name: string
}

type AreaFormState = {
  area_id?: number
  area_code: string
  area_name: string
}

export type AreaFormSubmitPayload = {
  submit: (actor_id: string) => Promise<void>
}

const props = defineProps<{
  visible: boolean
  mode: AreaFormMode
  model: AreaFormModel | null
}>()

const emit = defineEmits<{
  (e: 'update:visible', v: boolean): void
  (e: 'submit', payload: AreaFormSubmitPayload): void
  (e: 'close'): void
}>()

const isView = computed(() => props.mode === 'view')
const title = computed(() =>
  props.mode === 'new' ? 'New Area' : props.mode === 'edit' ? 'Edit Area' : 'Area Detail',
)

const submitted = ref(false)

const form = reactive<AreaFormState>({
  area_id: undefined,
  area_code: '',
  area_name: '',
})

const areaCodeError = computed(() => submitted.value && !String(form.area_code ?? '').trim())
const areaNameError = computed(() => submitted.value && !String(form.area_name ?? '').trim())

watch(
  () => props.model,
  (m) => {
    if (!m) return
    submitted.value = false
    form.area_id = m.area_id
    form.area_code = m.area_code ?? ''
    form.area_name = m.area_name ?? ''
  },
  { immediate: true },
)

function close() {
  submitted.value = false
  emit('update:visible', false)
  emit('close')
}

function submit() {
  submitted.value = true

  const code = String(form.area_code ?? '').trim()
  const name = String(form.area_name ?? '').trim()

  if (!code || !name) return

  emit('submit', {
    submit: async (actor_id: string) => {
      if (props.mode === 'new') {
        await createAreaMock({
          area_code: code,
          area_name: name,
          actor_id,
        })
        return
      }

      if (!form.area_id) throw new Error('AREA_NOT_FOUND')

      await updateAreaMock({
        area_id: form.area_id,
        area_code: code,
        area_name: name,
        actor_id,
      })
    },
  })
}
</script>

<template>
  <Dialog
    :visible="visible"
    modal
    :header="title"
    :style="{ width: '860px', maxWidth: '95vw' }"
    :contentStyle="{ maxHeight: '70vh', overflow: 'auto' }"
    @update:visible="emit('update:visible', $event)"
    @hide="close"
  >
    <div v-if="!model" class="text-slate-500">No data.</div>

    <div v-else class="space-y-4">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label class="block text-sm text-slate-600 mb-1">Area Code</label>
          <div v-if="isView" class="text-slate-800 font-semibold">{{ form.area_code }}</div>
          <BaseInput
            v-else
            v-model="form.area_code"
            label=""
            size="small"
            placeholder="Enter code"
            :hasError="areaCodeError"
            message="Area Code is required"
          />
        </div>

        <div>
          <label class="block text-sm text-slate-600 mb-1">Area Name</label>
          <div v-if="isView" class="text-slate-800 font-semibold">{{ form.area_name }}</div>
          <BaseInput
            v-else
            v-model="form.area_name"
            label=""
            size="small"
            placeholder="Enter name"
            :hasError="areaNameError"
            message="Area Name is required"
          />
        </div>
      </div>

      <div class="flex justify-end gap-2 pt-3 border-t border-slate-200">
        <BaseButton label="Cancel" severity="danger" outlined @click="close" />
        <BaseButton v-if="!isView" label="Submit" severity="success" @click="submit" />
      </div>
    </div>
  </Dialog>
</template>
